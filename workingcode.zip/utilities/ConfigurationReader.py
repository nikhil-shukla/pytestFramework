import os
from configparser import ConfigParser
import logging
from utilities.LogUtils import Logger

logger = Logger()
log = logger.logger_setup(logging.DEBUG)


def read_config(section, key):
    config = ConfigParser()
    file_path = "configurations//config.ini"
    config.read(file_path)
    return config.get(section, key)


def read_homePageLocators(key):
    section = "HOME PAGE"
    config = ConfigParser()
    file_path = "resources//locators//homePage_locators.ini"
    config.read(file_path)
    return config.get(section, key)
