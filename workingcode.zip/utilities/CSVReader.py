import csv
import os


class ReadCSV:

    @staticmethod
    def read_csv_by_id(filepath, target_id, key):
        with open(filepath, 'r', newline='') as file:
            reader = csv.DictReader(file)
            for row in reader:
                if row['ID'] == target_id:
                    result = dict(row)
                    return result[key]
            else:
                print(f"No data found for ID {target_id}")
        return None

    @staticmethod
    def read_csv_row(filepath, row_number):
        with open(filepath, 'r', newline='') as csvfile:
            csv_reader = csv.reader(csvfile)
            for _ in range(row_number - 1):
                next(csv_reader)
            return next(csv_reader)

    @staticmethod
    def read_csv(filepath):
        with open(filepath, 'r', newline='') as csvfile:
            csv_reader = csv.reader(csvfile)
            header_skipped = False
            data = []
            for row in csv_reader:
                if not header_skipped:
                    header_skipped = True
                    continue
                data.append(row)
            return data