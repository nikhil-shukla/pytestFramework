class Utils:

    def assert_text_in_list(self, list, value):
        for item in list:
            assert item == value

