import logging
import os
import time
from selenium.webdriver.common.by import By
from pages.BasePage import BasePage
from utilities.ConfigurationReader import read_homePageLocators
from utilities.LogUtils import Logger


class HomePage(BasePage):

    def __init__(self, driver):
        super().__init__(driver)

    logger = Logger()
    log = logger.logger_setup(logging.DEBUG)

    emailInput = read_homePageLocators("EMAIL_INPUT")
    pwdInput = read_homePageLocators("PWD_INPUT")
    loginBtn = read_homePageLocators("LOGIN_BTN")
    glasswallLabel = read_homePageLocators("GLASSWALL_LABEL")
    productTxt = read_homePageLocators("PRODUCT_TXT")
    logoutBtn = read_homePageLocators("LOGOUT_BTN")

    def login(self, email, pwd):
        self.wait_for_element_clickable(timeout=10, locator=self.emailInput)
        self.take_element_screenshot(self.emailInput)
        self.input_text(self.emailInput, email)
        self.input_text(self.pwdInput, pwd)
        self.click_element(self.loginBtn)
        self.wait_for_element_presence(timeout=7, locator=self.glasswallLabel)
        if "amd" not in email:
            self.wait_for_element_presence(timeout=10, locator=self.productTxt)
            products = self.get_elements(self.productTxt)
            product1 = self.get_element(self.productTxt).text
            self.log.info(product1)
            productList = []
            for product in products:
                prod = product.text
                productList.append(prod)
            self.log.info(productList)
            self.take_full_page_screenshot()

    def logout(self):
        self.wait_for_element_clickable(timeout=7, locator=self.logoutBtn)
        self.click_element(self.logoutBtn)
