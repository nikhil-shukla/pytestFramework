import logging
import time
from selenium.webdriver.common.by import By
from pages.BasePage import BasePage
from utilities.ConfigurationReader import read_homePageLocators
from utilities.LogUtils import Logger


class NextPage(BasePage):

    def __init__(self, driver):
        super().__init__(driver)

    logger = Logger()
    log = logger.logger_setup(logging.DEBUG)

    radio1Btn = read_homePageLocators("RADIO1_BTN")
    suggestInput = read_homePageLocators("SUGGEST_INPUT")
    suggestValue = read_homePageLocators("SUGGEST_VALUE")
    dropdown = read_homePageLocators("DROPDOWN")

    def practice(self, country, option_value, option_index, option_txt):
        time.sleep(2)
        # radio btn
        self.click_element(self.radio1Btn)
        time.sleep(5)

        # suggestion input
        if self.wait_for_element_clickable(locator=self.suggestInput):
            self.input_text(self.suggestInput, country)
            time.sleep(2)
            all_values = self.get_elements(self.suggestValue)
            for value in all_values:
                if value.text == country:
                    value.click()
                    break
        time.sleep(2)

        # dropdown
        print(self.get_all_options_text(self.dropdown))
        self.select_option_by_value(self.dropdown, option_value)
        print(self.get_selected_option_text(self.dropdown))
        time.sleep(2)
        self.select_option_by_index(self.dropdown, option_index)
        print(self.get_selected_option_text(self.dropdown))
        time.sleep(2)
        self.select_option_by_visible_text(self.dropdown, option_txt)
        print(self.get_selected_option_text(self.dropdown))
        time.sleep(2)

        # checkbox

