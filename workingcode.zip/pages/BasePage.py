import logging
import os
import time
from selenium.common import NoAlertPresentException, NoSuchElementException, NoSuchFrameException
from selenium.webdriver import Keys, ActionChains
from selenium.webdriver.common.by import By
from selenium.webdriver.support.select import Select
from selenium.webdriver.support.wait import WebDriverWait
from selenium.webdriver.support import expected_conditions as EC
from utilities.LogUtils import Logger


class BasePage:

    def __init__(self, driver):
        self.driver = driver

    logger = Logger()
    log = logger.logger_setup(logging.DEBUG)

    def get_locator(self, locator):
        strategy, value = locator.split("_")
        strategy = strategy.lower()

        strategies = {
            "id": By.ID,
            "name": By.NAME,
            "classname": By.CLASS_NAME,
            "linktext": By.LINK_TEXT,
            "xpath": By.XPATH,
            "css": By.CSS_SELECTOR,
            "partiallinktext": By.PARTIAL_LINK_TEXT,
            "tagname": By.TAG_NAME,
        }

        if strategy not in strategies:
            raise ValueError(f"Invalid locator strategy: {strategy.upper()}")

        return strategies[strategy], value

    def get_element(self, locator):
        strategy, value = locator.split("_")
        strategy = strategy.lower()

        strategies = {
            "id": By.ID,
            "name": By.NAME,
            "classname": By.CLASS_NAME,
            "linktext": By.LINK_TEXT,
            "xpath": By.XPATH,
            "css": By.CSS_SELECTOR,
            "partiallinktext": By.PARTIAL_LINK_TEXT,
            "tagname": By.TAG_NAME,
        }

        if strategy not in strategies:
            raise ValueError(f"Invalid locator strategy: {strategy.upper()}")

        try:
            return self.driver.find_element(strategies[strategy], value)
        except NoSuchElementException as e:
            self.log.info(f"Element not found: {e}")
            raise

    def get_elements(self, locator):
        strategy, value = locator.split("_")
        strategy = strategy.lower()

        strategies = {
            "id": By.ID,
            "name": By.NAME,
            "classname": By.CLASS_NAME,
            "linktext": By.LINK_TEXT,
            "xpath": By.XPATH,
            "css": By.CSS_SELECTOR,
            "partiallinktext": By.PARTIAL_LINK_TEXT,
            "tagname": By.TAG_NAME,
        }

        if strategy not in strategies:
            raise ValueError(f"Invalid locator strategy: {strategy.upper()}")

        try:
            return self.driver.find_elements(strategies[strategy], value)
        except NoSuchElementException as e:
            self.log.info(f"Elements not found: {e}")
            raise

    def click_element(self, locator):
        element = self.get_element(locator)
        try:
            element.click()
            self.log.info("Clicked the webelement.")
        except Exception as e:
            self.log.error(f"Unable to click element. {e}")

    def input_text(self, locator, text):
        element = self.get_element(locator)
        try:
            element.click()
            time.sleep(1)
            element.clear()
            time.sleep(1)
            element.send_keys(text)
            self.log.info(f"Entered the text.")
        except Exception as e:
            self.log.error(f"Unable to enter text. {e}")

    def press_enterKey(self, locator):
        element = self.get_element(locator)
        try:
            element.send_keys(Keys.ENTER)
            self.log.info(f"Pressed the Enter key.")
        except Exception as e:
            self.log.error(f"Unable to press enter key. {e}")

    def get_title(self):
        return self.driver.title

    def check_element_displayed(self, locator):
        element = self.get_element(locator)
        return element.is_displayed()

    def explicit_wait(self, timeout=5):
        wait = WebDriverWait(self.driver, timeout)
        return wait

    def wait_for_element_clickable(self, timeout=5, locator=None):
        try:
            element = self.explicit_wait(timeout).until(
                EC.element_to_be_clickable((self.get_locator(locator)))
            )
            self.log.info(f"Element = {locator} can be clicked")
            return element
        except Exception:
            self.log.error(f"Element = {locator} CANNOT be clicked")
            raise

    def wait_for_element_presence(self, timeout=5, locator=None):
        try:
            element = self.explicit_wait(timeout).until(
                EC.presence_of_element_located((self.get_locator(locator)))
            )
            self.log.info(f"Element = {locator} presence is located")
            return element
        except Exception:
            self.log.error(f"Element = {locator} presence cannot be located")
            raise

    def switch_to_latest_window(self):
        try:
            window_handles = self.driver.window_handles
            self.driver.switch_to.window(window_handles[-1])
        except Exception as e:
            self.log.error(f"Error switching to the latest window. {e}")
            raise

    def get_text(self, locator):
        element = self.get_element(locator)
        try:
            string_text = element.text
            self.log.info(f"The text is {string_text}")
            return string_text
        except Exception as e:
            self.log.error(f"Unable to fetch element text. {e}")

    def accept_alert(self):
        try:
            alert = self.driver.switch_to.alert
            alert.accept()
        except NoAlertPresentException as e:
            self.log.error(f"No alert present. {e}")
            raise

    def dismiss_alert(self):
        try:
            alert = self.driver.switch_to.alert
            alert.dismiss()
        except NoAlertPresentException as e:
            self.log.error(f"No alert present. {e}")
            raise

    def switch_to_window(self, window_handle):
        try:
            self.driver.switch_to.window(window_handle)
        except Exception as e:
            self.log.error(f"Error switching to window {window_handle}. {e}")
            raise

    def switch_to_window_by_index(self, index):
        try:
            window_handles = self.driver.window_handles
            self.driver.switch_to.window(window_handles[index])
        except IndexError as e:
            self.log.error(f"Error switching to window by index {index}. {e}")
            raise

    def switch_to_window_containing_title(self, title):
        try:
            for window_handle in self.driver.window_handles:
                self.driver.switch_to.window(window_handle)
                if title in self.driver.title:
                    return
            raise NoSuchElementException(f"No window with title containing '{title}' found.")
        except NoSuchElementException as e:
            self.log.error(f"Error switching to window containing title '{title}'. {e}")
            raise

    def switch_to_window_containing_url(self, url):
        try:
            for window_handle in self.driver.window_handles:
                self.driver.switch_to.window(window_handle)
                if url in self.driver.current_url:
                    return
            raise NoSuchElementException(f"No window with URL containing '{url}' found.")
        except NoSuchElementException as e:
            self.log.error(f"Error switching to window containing URL '{url}'. {e}")
            raise

    def switch_to_frame_by_index(self, index):
        try:
            self.driver.switch_to.frame(index)
        except NoSuchFrameException as e:
            self.log.error(f"Error switching to frame by index {index}. {e}")
            raise

    def switch_to_frame_by_name_or_id(self, name_or_id):
        try:
            self.driver.switch_to.frame(name_or_id)
        except NoSuchFrameException as e:
            self.log.error(f"Error switching to frame by name or id '{name_or_id}'. {e}")
            raise

    def switch_to_frame_by_element(self, frame_element):
        try:
            self.driver.switch_to.frame(frame_element)
        except NoSuchFrameException as e:
            self.log.error(f"Error switching to frame by element. {e}")
            raise

    def switch_to_default_content(self):
        try:
            self.driver.switch_to.default_content()
        except NoSuchFrameException as e:
            self.log.error(f"Error switching to default content. {e}")
            raise

    def select_option_by_visible_text(self, locator, option_text):
        try:
            dropdown = Select(self.get_element(locator))
            dropdown.select_by_visible_text(option_text)
        except NoSuchElementException as e:
            self.log.error(f"Error selecting option by visible text. {e}")
            raise

    def select_option_by_value(self, locator, option_value):
        try:
            dropdown = Select(self.get_element(locator))
            dropdown.select_by_value(option_value)
        except NoSuchElementException as e:
            self.log.error(f"Error selecting option by value. {e}")
            raise

    def select_option_by_index(self, locator, index):
        try:
            dropdown = Select(self.get_element(locator))
            dropdown.select_by_index(index)
        except NoSuchElementException as e:
            self.log.error(f"Error selecting option by index. {e}")
            raise

    def get_selected_option_text(self, locator):
        try:
            dropdown = Select(self.get_element(locator))
            return dropdown.first_selected_option.text
        except NoSuchElementException as e:
            self.log.error(f"Error getting selected option text. {e}")
            raise

    def get_all_options_text(self, locator):
        try:
            dropdown = Select(self.get_element(locator))
            return [option.text for option in dropdown.options]
        except NoSuchElementException as e:
            self.log.error(f"Error getting all options text. {e}")
            raise

    def deselect_option_by_visible_text(self, locator, option_text):
        try:
            dropdown = Select(self.get_element(locator))
            dropdown.deselect_by_visible_text(option_text)
        except NoSuchElementException as e:
            self.log.error(f"Error deselecting option by visible text. {e}")
            raise

    def deselect_option_by_value(self, locator, option_value):
        try:
            dropdown = Select(self.get_element(locator))
            dropdown.deselect_by_value(option_value)
        except NoSuchElementException as e:
            self.log.error(f"Error deselecting option by value. {e}")
            raise

    def deselect_option_by_index(self, locator, index):
        try:
            dropdown = Select(self.get_element(locator))
            dropdown.deselect_by_index(index)
        except NoSuchElementException as e:
            self.log.error(f"Error deselecting option by index. {e}")
            raise

    def deselect_all_options(self, locator):
        try:
            dropdown = Select(self.get_element(locator))
            dropdown.deselect_all()
        except NoSuchElementException as e:
            self.log.error(f"Error deselecting all options. {e}")
            raise

    def scroll_to_element(self, locator):
        try:
            element = self.get_element(locator)
            self.driver.execute_script("arguments[0].scrollIntoView(true);", element)
        except NoSuchElementException as e:
            self.log.error(f"Error scrolling to element by locator key '{locator}'. {e}")
            raise

    def scroll_to_bottom(self):
        try:
            self.driver.execute_script("window.scrollTo(0, document.body.scrollHeight);")
        except Exception as e:
            self.log.error(f"Error scrolling to the bottom of the page. {e}")
            raise

    def scroll_to_top(self):
        try:
            self.driver.execute_script("window.scrollTo(0, 0);")
        except Exception as e:
            self.log.error(f"Error scrolling to the top of the page. {e}")
            raise

    def perform_hover(self, locator):
        try:
            element = self.get_element(locator)
            ActionChains(self.driver).move_to_element(element).perform()
        except NoSuchElementException as e:
            self.log.error(f"Error performing hover on element by locator key '{locator}'. {e}")
            raise

    def perform_drag_and_drop(self, source_locator, target_locator):
        try:
            source_element = self.get_element(source_locator)
            target_element = self.get_element(target_locator)
            ActionChains(self.driver).drag_and_drop(source_element, target_element).perform()
        except NoSuchElementException as e:
            self.log.error(f"Error performing drag and drop. {e}")
            raise

    def perform_double_click(self, locator):
        try:
            element = self.get_element(locator)
            ActionChains(self.driver).double_click(element).perform()
        except NoSuchElementException as e:
            self.log.error(f"Error performing double click on element by locator key '{locator}'. {e}")
            raise

    def perform_context_click(self, locator):
        try:
            element = self.get_element(locator)
            ActionChains(self.driver).context_click(element).perform()
        except NoSuchElementException as e:
            self.log.error(f"Error performing context click on element by locator key '{locator}'. {e}")
            raise

    def perform_key_press(self, key):
        try:
            ActionChains(self.driver).key_down(key).key_up(key).perform()
        except Exception as e:
            self.log.error(f"Error performing key press for key '{key}'. {e}")
            raise

    def _create_screenshot_directory(self, directory_path):
        try:
            os.makedirs(directory_path, exist_ok=True)
        except OSError as e:
            self.log.error(f"Error creating screenshot directory '{directory_path}'. {e}")
            raise

    def take_full_page_screenshot(self, directory="target\\screenshots", prefix="full_page", extension=".png"):
        try:
            self._create_screenshot_directory(directory)
            file_path = os.path.join(directory, f"{prefix}_{self._get_timestamp()}{extension}")
            self.driver.save_screenshot(file_path)
            return file_path
        except Exception as e:
            self.log.error(f"Error taking full page screenshot. {e}")
            raise

    def take_element_screenshot(self, locator, directory="target\\screenshots", prefix="element", extension=".png"):
        try:
            element = self.get_element(locator)
            self._create_screenshot_directory(directory)
            file_path = os.path.join(directory, f"{prefix}_{self._get_timestamp()}{extension}")
            element.screenshot(file_path)
            return file_path
        except NoSuchElementException as e:
            self.log.error(f"Error taking element screenshot by locator key '{locator}'. {e}")
            raise

    def take_viewport_screenshot(self, directory="target\\screenshots", prefix="viewport", extension=".png"):
        try:
            self._create_screenshot_directory(directory)
            file_path = os.path.join(directory, f"{prefix}_{self._get_timestamp()}{extension}")
            screenshot_data = self.driver.get_screenshot_as_png()
            with open(file_path, "wb") as screenshot_file:
                screenshot_file.write(screenshot_data)
            return file_path
        except Exception as e:
            self.log.error(f"Error taking viewport screenshot. {e}")
            raise

    def _get_timestamp(self):
        import datetime
        return datetime.datetime.now().strftime("%Y%m%d_%H%M%S")

    def close_current_window(self):
        try:
            self.driver.close()
        except Exception as e:
            self.log.error(f"Error closing the current window. {e}")
            raise

    def close_browser(self):
        self.driver.quit()
