# import logging
# import pytest
# from pages.HomePage import HomePage
# from pages.NextPage import NextPage
# from tests.BaseTest import BaseTest
# from utilities.LogUtils import Logger
#
#
# class TestPractice(BaseTest):
#     logger = Logger()
#     log = logger.logger_setup(logging.DEBUG)
#
#     @pytest.mark.practice
#     def test_selenium(self):
#         nextpage = NextPage(self.driver)
#         self.log.info(nextpage.get_title())
#         nextpage.practice("India", "option1", 2, "Option3")
