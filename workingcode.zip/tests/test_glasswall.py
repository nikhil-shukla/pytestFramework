import logging
import time
import pytest
import allure
from allure_commons.types import AttachmentType
from pages.HomePage import HomePage
from tests.BaseTest import BaseTest
from utilities.CSVReader import ReadCSV
from utilities.LogUtils import Logger
from utilities.ConfigurationReader import read_config


class TestGlasswall(BaseTest, ReadCSV):

    @pytest.fixture(autouse=True)
    def class_setup(self):
        self.homepage = HomePage(self.driver)
        self.logger = Logger()
        self.log = self.logger.logger_setup(logging.DEBUG)
        self.log.info("Setting up the test.")

    @pytest.mark.sanity
    def test_login(self):
        title = self.driver.title
        self.log.info(title)
        email = read_config("BASIC INFO", "EMAIL")
        pwd = read_config("BASIC INFO", "PWD")
        self.homepage.login(email, pwd)
        self.homepage.logout()

    @pytest.mark.parametrize("email, pwd", [(row[1], row[2]) for row in ReadCSV.read_csv("resources//testdata"
                                                                                         "//testdata.csv")])
    def test_login_multiple_users(self, email, pwd):
        title = self.driver.title
        self.log.info(title)
        self.homepage.login(email, pwd)
        self.homepage.logout()
